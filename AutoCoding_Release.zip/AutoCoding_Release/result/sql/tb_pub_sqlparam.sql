delete from tb_pub_sqlparam t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2487, 'QUERY_SUBSIDY_REPORT', 'select a.billing_cycle_begin,
       a.billing_cycle_end,
       d.pre_rule_id,
       d.pre_rule_name,
       DECODE(A.OBJ_TYPE, ''0'', ''�˻���'', ''1'', ''�û���''),
       c.developer,
       c.developer_code,
       c.staff_id,
       e.cust_name,
       e.cust_id,
       case
         when a.obj_type = ''0'' then
          (select ac.account_name
             from account_{[LATN_ID:%ld]} ac
            where ac.account_id = a.obj_id)
         else
          (select pa.attr_value
             from prod_inst_attr_{[LATN_ID:%ld]} pa
            where pa.prod_inst_id = a.obj_id
              and pa.attr_id = 700004)
       end acct_name,
       case
         when a.obj_type = ''0'' then
          (select ac.account_number
             from account_{[LATN_ID:%ld]} ac
            where ac.account_id = a.obj_id)
         else
          (select pi.acc_nbr
             from prod_inst_{[LATN_ID:%ld]} pi
            where pi.prod_inst_id = a.obj_id)
       end acct_nbr
  from tb_bil_pre_inst_{[LATN_ID:%ld]}      a,
       mv_prd_pre_rule_inst_{[LATN_ID:%ld]} b,
       customer_order_{[LATN_ID:%ld]}       c,
       tb_bil_pre_rule          d,
       cust_{[LATN_ID:%ld]}                 e
 where a.pre_inst_id = b.pre_inst_id
   and b.install_order_id = c.cust_order_id
   and a.pre_rule_id = d.pre_rule_id
   and b.own_cust_id = e.cust_id
 
', '1', null, 'QUERY_SUBSIDY_REPORT', 1, 12, 0, '550', '');


