/*
 * DCCrmQuerySubsidyReport.cpp
 *
 *  Created on: 2015��7��24��
 *      Author: HDZhang
 */


#include "DCCrmQuerySubsidyReport.h"
#include "DCCrmDBAgent.h"
#include "DCCommService.h"
#include "DCServiceStructDef.h" //Used for DEF_PAGE_SIZE

CRM_NAMESPACE_BEGIN(svc)

DYN_CLASS_IMP(DCCrmQuerySubsidyReport)

static void string_replace(string& s1, const string& s2, const string& s3)
{
    string::size_type pos = 0;
    string::size_type a = s2.size();
    string::size_type b = s3.size();
    while ((pos = s1.find(s2, pos)) != string::npos) {
        s1.replace(pos, a, s3);
        pos += b;
    }
}

DCCrmQuerySubsidyReport::DCCrmQuerySubsidyReport(const char* clsName):
DCAtomService(clsName)
{
	m_nSvrType=ATOM_SERVICE_TYPE_SELECT;
	strcpy(m_szPublishName,"QUERY_SUBSIDY_REPORT");
	l_QuerySubsidyReportOut.clear();
	l_QuerySubsidyReportIn.clear();
}

int DCCrmQuerySubsidyReport::GetInputParam(DCObject *pBuffer)
{

	DCTuxBuffer *pTuxBuffer = (DCTuxBuffer*)pBuffer;
	STQuerySubsidyReportIn stQuerySubsidyReportIn;
	memset(&stQuerySubsidyReportIn,0x00,sizeof(stQuerySubsidyReportIn));

		if(pTuxBuffer->GetValue("LATN_ID",stQuerySubsidyReportIn.LATN_ID)<0)
		{
			CRM_LOG((LC_DEBUG,"get parameter[LATN_ID]  failed"));
			return -1;
		}
		CRM_LOG((LC_DEBUG,"get parameter[LATN_ID]  is %s",stQuerySubsidyReportIn.LATN_ID));


		pTuxBuffer->GetValue("ACCT_NBR",stQuerySubsidyReportIn.ACCT_NBR);
		CRM_LOG((LC_DEBUG,"get parameter[ACCT_NBR]  is %s",stQuerySubsidyReportIn.ACCT_NBR));


		pTuxBuffer->GetValue("PRE_RULE_ID",stQuerySubsidyReportIn.PRE_RULE_ID);
		CRM_LOG((LC_DEBUG,"get parameter[PRE_RULE_ID]  is %s",stQuerySubsidyReportIn.PRE_RULE_ID));


		pTuxBuffer->GetValue("ACCEPT_USER",stQuerySubsidyReportIn.ACCEPT_USER);
		CRM_LOG((LC_DEBUG,"get parameter[ACCEPT_USER]  is %s",stQuerySubsidyReportIn.ACCEPT_USER));


		pTuxBuffer->GetValue("CUST_ID",stQuerySubsidyReportIn.CUST_ID);
		CRM_LOG((LC_DEBUG,"get parameter[CUST_ID]  is %s",stQuerySubsidyReportIn.CUST_ID));


		pTuxBuffer->GetValue("RULE_TYPE",stQuerySubsidyReportIn.RULE_TYPE);
		CRM_LOG((LC_DEBUG,"get parameter[RULE_TYPE]  is %s",stQuerySubsidyReportIn.RULE_TYPE));


		pTuxBuffer->GetValue("ACCEPT_START_TIME",stQuerySubsidyReportIn.ACCEPT_START_TIME);
		CRM_LOG((LC_DEBUG,"get parameter[ACCEPT_START_TIME]  is %s",stQuerySubsidyReportIn.ACCEPT_START_TIME));


		pTuxBuffer->GetValue("ACCEPT_END_TIME",stQuerySubsidyReportIn.ACCEPT_END_TIME);
		CRM_LOG((LC_DEBUG,"get parameter[ACCEPT_END_TIME]  is %s",stQuerySubsidyReportIn.ACCEPT_END_TIME));

	this->l_QuerySubsidyReportIn.push_back(stQuerySubsidyReportIn);

	return 0;
}

int DCCrmQuerySubsidyReport::BusinessProcess()
{

	int nErrorCode = 0;
	int class_id = QUERY_SUBSIDY_REPORT_DEF;

	list<STQuerySubsidyReportIn>::iterator iter=l_QuerySubsidyReportIn.begin();
	for(;iter!=l_QuerySubsidyReportIn.end();iter++)
	{
		long nLATN_ID=iter->LATN_ID;

		string extraSQL="";
		list<char*> l_ExtraValue;
		bool isFirst=true;

		if(iter->ACCT_NBR[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" ACCT_NBR=:ACCT_NBR ";
			l_ExtraValue.push_back(iter->ACCT_NBR);
			isFirst=false;
		}

		if(iter->PRE_RULE_ID[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" PRE_RULE_ID=:PRE_RULE_ID ";
			l_ExtraValue.push_back(iter->PRE_RULE_ID);
			isFirst=false;
		}

		if(iter->ACCEPT_USER[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" ACCEPT_USER=:ACCEPT_USER ";
			l_ExtraValue.push_back(iter->ACCEPT_USER);
			isFirst=false;
		}

		if(iter->CUST_ID[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" CUST_ID=:CUST_ID ";
			l_ExtraValue.push_back(iter->CUST_ID);
			isFirst=false;
		}

		if(iter->RULE_TYPE[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" RULE_TYPE=:RULE_TYPE ";
			l_ExtraValue.push_back(iter->RULE_TYPE);
			isFirst=false;
		}

		if(iter->ACCEPT_START_TIME[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" ACCEPT_START_TIME=:ACCEPT_START_TIME ";
			l_ExtraValue.push_back(iter->ACCEPT_START_TIME);
			isFirst=false;
		}

		if(iter->ACCEPT_END_TIME[0]!='\0')
		{
			if(!isFirst)
			{
				extraSQL+="AND";
			}
			extraSQL+=" ACCEPT_END_TIME=:ACCEPT_END_TIME ";
			l_ExtraValue.push_back(iter->ACCEPT_END_TIME);
			isFirst=false;
		}


		DCCrmDBAgent dbAgent;
		if (InitDBAgent(&dbAgent, class_id, true, nLATN_ID, nLATN_ID,extraSQL) < 0) {
			return -1;
		}

		if ((nErrorCode = dbAgent.BindParam((void*)&(*iter))) < 0) {
			CRM_LOG((LC_ERROR,"Bind SQL[%ld] failed %s", class_id, dbAgent.GetErrorMsg()));
			this->SetErrorMsg(nErrorCode, "Bind SQL[%ld] failed ", class_id);
			return -1;
		}
		
		list<char*>::iterator iter_temp=l_ExtraValue.begin();
		while(iter_temp!=l_ExtraValue.end())
		{
			dbAgent.BindExtraParam(*iter_temp);
			iter_temp++;
		}
				


		DCDataSet *pDataSet = dbAgent.Open();
		if (NULL == pDataSet) {
			CRM_LOG((LC_ERROR,"Execute SQL[%ld] failed %s", class_id, dbAgent.GetErrorMsg()));
			this->SetErrorMsg(CRM_ERROR_EXE_SQl_FAILED, "Execute SQL[%ld] failed ", class_id);
			return -1;
		}

		int row = 0;
		STQuerySubsidyReportOut offersOut[DEF_PAGE_SIZE] = {0};

		while ((row = pDataSet->GetRows((void*) offersOut, DEF_PAGE_SIZE)) > 0) {
			l_QuerySubsidyReportOut.insert(l_QuerySubsidyReportOut.end(),
					offersOut, offersOut + row);
			m_nRowTotal += row;
		}

		if (row < 0) {
			CRM_LOG((LC_ERROR,"Get dataset failed for sql [%ld]",class_id));
			this->SetErrorMsg(CRM_ERROR_DATASET_FAILED, "Get dataset failed for sql [%ld]", class_id);
			return -1;
		}

		m_nRowTotal = dbAgent.GetTotalCount();
	}
	return 0;
}

int DCCrmQuerySubsidyReport::SetOutputParam(DCObject *pBuffer)
{
	DCTuxBuffer *pTuxBuffer = (DCTuxBuffer*)pBuffer;

	char Fml32Tag[32] = "SUBSIDY_INST";

	DCTuxBuffer *pOutBuffer = (DCTuxBuffer *)pTuxBuffer->CreateNesteBuffer(Fml32Tag,l_QuerySubsidyReportOut.size()*sizeof(STQuerySubsidyReportOut),SEND_BUF);
	if (pOutBuffer == NULL)
	{
		CRM_LOG((LC_ERROR,"create nested buffer [%s] failed",Fml32Tag));
		this->SetErrorMsg(CRM_ERROR_BUFPTR_ISNULL,"create nested buffer [%s] failed",Fml32Tag);
		return -1;
	}

	list<STQuerySubsidyReportOut>::iterator iter;
	pOutBuffer->RsOpen();
	for (iter=l_QuerySubsidyReportOut.begin(); iter!=l_QuerySubsidyReportOut.end(); iter++)
	{
		pOutBuffer->RsAddRow();
		
		pOutBuffer->RsSetCol("BILLING_CYCLE_BEGIN", iter->BILLING_CYCLE_BEGIN);
		CRM_LOG((LC_DEBUG,"get output param BILLING_CYCLE_BEGIN[%s]",iter->BILLING_CYCLE_BEGIN));
		
		pOutBuffer->RsSetCol("BILLING_CYCLE_END", iter->BILLING_CYCLE_END);
		CRM_LOG((LC_DEBUG,"get output param BILLING_CYCLE_END[%s]",iter->BILLING_CYCLE_END));
		
		pOutBuffer->RsSetCol("PRE_RULE_ID", iter->PRE_RULE_ID);
		CRM_LOG((LC_DEBUG,"get output param PRE_RULE_ID[%s]",iter->PRE_RULE_ID));
		
		pOutBuffer->RsSetCol("PRE_RULE_NAME", iter->PRE_RULE_NAME);
		CRM_LOG((LC_DEBUG,"get output param PRE_RULE_NAME[%s]",iter->PRE_RULE_NAME));
		
		pOutBuffer->RsSetCol("OBJ_TYPE", iter->OBJ_TYPE);
		CRM_LOG((LC_DEBUG,"get output param OBJ_TYPE[%s]",iter->OBJ_TYPE));
		
		pOutBuffer->RsSetCol("DEVELOPER", iter->DEVELOPER);
		CRM_LOG((LC_DEBUG,"get output param DEVELOPER[%s]",iter->DEVELOPER));
		
		pOutBuffer->RsSetCol("DEVELOPER_CODE", iter->DEVELOPER_CODE);
		CRM_LOG((LC_DEBUG,"get output param DEVELOPER_CODE[%s]",iter->DEVELOPER_CODE));
		
		pOutBuffer->RsSetCol("STAFF_ID", iter->STAFF_ID);
		CRM_LOG((LC_DEBUG,"get output param STAFF_ID[%s]",iter->STAFF_ID));
		
		pOutBuffer->RsSetCol("CUST_NAME", iter->CUST_NAME);
		CRM_LOG((LC_DEBUG,"get output param CUST_NAME[%s]",iter->CUST_NAME));
		
		pOutBuffer->RsSetCol("CUST_ID", iter->CUST_ID);
		CRM_LOG((LC_DEBUG,"get output param CUST_ID[%s]",iter->CUST_ID));
		
		pOutBuffer->RsSetCol("ACCT_NAME", iter->ACCT_NAME);
		CRM_LOG((LC_DEBUG,"get output param ACCT_NAME[%s]",iter->ACCT_NAME));
		
		pOutBuffer->RsSetCol("ACCT_NBR", iter->ACCT_NBR);
		CRM_LOG((LC_DEBUG,"get output param ACCT_NBR[%s]",iter->ACCT_NBR));

		pOutBuffer->RsSaveRow();
	}
	pTuxBuffer->SetfValue(Fml32Tag,pOutBuffer);

	return 0;
}

int DCCrmQuerySubsidyReport::InitDBAgent(DCCrmDBAgent* pDBAgent, long nClassId, bool bReply, long nLocLatnId, long nTabLatnId,string extraSQL)
{
    char cntKey[32] = {0};
    if (0 != nLocLatnId) {
        ReplaceSql((cntKey, "{[LATN_ID:%ld]}", nLocLatnId));
    } else {
        ReplaceSql((cntKey, ""));
    }

    DCDBConnection *pConnection = (DCDBConnection * )((DCCommService *) GetParent())->GetServiceConnection(cntKey, this);
    if (pConnection == NULL) {
        CRM_LOG((LC_ERROR, "get database connection failed"));
        this->SetErrorMsg(CRM_ERROR_SERVICE_GETCONN_FAILED, "get database connection failed");
        return -1;
    }
    m_pConnection = pConnection;

    char *pSql = m_pSQLConfig->GetSql(nClassId);
    if (NULL == pSql) {
        CRM_LOG((LC_ERROR, "get sql [%ld] failed", nClassId));
        SetErrorMsg(CRM_ERROR_SERVICE_SQL_FAILED, "get sql[%ld] failed", nClassId);
        return CRM_ERROR_SERVICE_SQL_FAILED;
    }

    pDBAgent->SetConnection(pConnection);
    long nErrorCode = 0;
    if ((nErrorCode = pDBAgent->SetSql(nClassId, bReply)) < 0) {
        CRM_LOG((LC_ERROR, pDBAgent->GetErrorMsg()));
        this->SetErrorMsg(CRM_ERROR_SERVICE_SQLCONF_FAILED, pDBAgent->GetErrorMsg());
        return nErrorCode;
    }

    string sql = " "+extraSQL;
    if (NULL != pSql) {
        sql = pSql+sql;
    } else {
        CRM_LOG((LC_ERROR, "Get Sql is NULL"));
        this->SetErrorMsg(-1, "Get Sql is NULL");
        return -1;
    }

    string tempSql(sql);
    string src("{[LATN_ID:%ld]}");
    char tempId[32] = {0};
    sprintf(tempId, "%ld", nTabLatnId);
    string des(tempId);
    string_replace(tempSql, src, des);

    int i = 0;
    const char *sql_use = tempSql.c_str();
    while (' ' == sql_use[i]) ++i;
    if (!('b' == sql_use[i] || 'B' == sql_use[i] ||
            'i' == sql_use[i] || 'I' == sql_use[i] ||
            'u' == sql_use[i] || 'U' == sql_use[i])) {
        pDBAgent->SetPage(m_pPubReq->nPageIndex, m_pPubReq->nPageSize);
    }

    if ((nErrorCode = pDBAgent->PrepareSQL((char *) tempSql.c_str())) < 0) {
        CRM_LOG((LC_ERROR, pDBAgent->GetErrorMsg()));
        this->SetErrorMsg(CRM_ERROR_SERVICE_GETCONN_FAILED, pDBAgent->GetErrorMsg());
        return nErrorCode;
    }
    return 0;
}

CRM_NAMESPACE_END()



